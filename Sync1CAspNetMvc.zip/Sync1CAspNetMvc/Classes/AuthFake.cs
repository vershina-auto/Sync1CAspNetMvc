﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Web;

namespace Sync1CAspNetMvc
{
    public class AuthFake : IAuth
    {
        const string CookieAuth = "authguid";
        const string CookieBasicAuth = "Authorization";

        const string AdminLogin = "admin";
        const string AdminPass = "12345";

        public bool CheckAuthBasic(HttpRequestBase request, out string cookieName, out string cookieValue)
        {
            var auth = request.Headers["Authorization"];
            if (!string.IsNullOrEmpty(auth))
            {
                var cred = ASCIIEncoding.ASCII.GetString(Convert.FromBase64String(auth.Substring(6))).Split(':');
                var user = new { Name = cred[0], Pass = cred[1] };
                if (user.Name == AdminLogin && user.Pass == AdminPass)
                {
                    cookieName = CookieAuth;
                    cookieValue = Guid.NewGuid().ToString();
                    return true;
                }
            }

            cookieName = "";
            cookieValue = "";
            return false;
        }
        public bool IsAuth(HttpRequestBase request)
        {
            var auth = request.Cookies[CookieAuth];
            return auth != null && !string.IsNullOrEmpty(auth.Value);
        }
    }
}