﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sync1CAspNetMvc
{
    public class OrdersFake : IOrders
    {
        public Order[] GetAll()
        {
            return new [] {
                new Order()
                {
                    IdGuid = "36f09a0a-4864-4e36-b6aa-d581f8cace02",
                    Id = "16123",
                    DateCreate = new DateTime(2018, 10, 1, 12, 4, 15),
                    Fio = "Иванов Иван Иванович",
                    
                    Products = new Product[]
                    {
                        new Product()
                        {
                            Id = "dcbfb7cf-7a66-4545-a100-c5e5c63035ab",
                            Name = "Товар 1",
                            Article = "156118",
                            Count = 10,
                            Price = 152.15d
                        },
                        new Product()
                        {
                            Id = "9353cf19-f1c3-4fa7-b0d2-bff82e80e75a",
                            Name = "Товар 2",
                            Article = "456478",
                            Count = 1,
                            Price = 9845.00d
                        }
                    }
                }
            };
        }


        public bool Update(Order[] orders)
        {
            return true;
        }
    }
}