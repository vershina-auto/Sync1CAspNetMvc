﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sync1CAspNetMvc
{
    public class ProductsFake : IProducts
    {
        public bool Upload(Product[] products)
        {
            return true;
        }
    }
}