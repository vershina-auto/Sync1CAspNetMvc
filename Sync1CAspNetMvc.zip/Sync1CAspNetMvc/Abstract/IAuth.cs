﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Sync1CAspNetMvc
{
    public interface IAuth
    {
        bool CheckAuthBasic(HttpRequestBase request, out string cookieName, out string cookieValue);
        bool IsAuth(HttpRequestBase request);
    }
}
