﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sync1CAspNetMvc
{
    public interface IProducts
    {
        bool Upload(Product[] products);
    }
}
