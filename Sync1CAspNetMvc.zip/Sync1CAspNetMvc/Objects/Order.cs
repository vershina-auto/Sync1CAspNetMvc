﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sync1CAspNetMvc
{
    public class Order
    {
        public string IdGuid { get; set; }
        public string Id { get; set; }
        public DateTime DateCreate { get; set; }
        public string Fio { get; set; }

        public Product[] Products { get; set; }

        public double TotalPrice { get { return Products.Sum(item => item.TotalPrice); } }
    }
}